"""Annual observations and prediction curves for forest fires."""
from pathlib import Path
import json,sys
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
from matplotlib.font_manager import fontManager
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import Patch

R=Path(__file__).resolve().parents[1]/'analysis/forest_recovery'
F=Path(__file__).resolve().parent/'figures'
Q=Path(__file__).resolve().parent/'results'
OUT=Path(__file__).resolve().parents[2]/'output/forest_report_english'
sys.path.insert(0,str(R))
from model import predict,quadratic,COEF
fontManager.addfont(str(R/'assets/NotoSansCJKsc-Regular.otf'))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False})
BLUE='#286D98';GREY='#959FA5';BLACK='#252A2D'
TARGETS=[('LG','R_LG','LG relative state'),('ZP_TCC','R_ZP_TCC','Canopy cover relative state'),('DE','DE','DE')]

def save_image(fig,path,**kwargs):
    temporary=path.with_suffix('.pending.png')
    fig.savefig(temporary,**kwargs)
    with Image.open(temporary) as check:check.load()
    temporary.replace(path)

def main():
    OUT.mkdir(parents=True,exist_ok=True);F.mkdir(exist_ok=True);Q.mkdir(exist_ok=True)
    coef=COEF
    folds={int(k):np.array(v) for k,v in json.loads((R/'results/validation_coefficients.json').read_text()).items()}
    roles=pd.read_csv(R/'data/events.csv').set_index('event_id')
    d=pd.read_csv(R/'data/rebuilt_annual_states.csv')
    widths=pd.read_csv(R/'results/interval_half_widths.csv');plotted=[]
    complete=d.groupby('event_id').t.nunique();balanced=d[d.event_id.isin(complete[complete.eq(8)].index)]
    mean=balanced.groupby('t')[['R_LG','R_ZP_TCC','DE']].mean()
    fig,axs=plt.subplots(1,2,figsize=(10.3,3.7))
    for col,label,color in [('R_LG','LG',BLUE),('R_ZP_TCC','Canopy cover','#B66F25')]:axs[0].plot(mean.index,100*mean[col],'o-',label=label,color=color)
    axs[0].set(xlabel='Post-fire year',ylabel='Relative state (points)',xticks=range(1,9));axs[0].legend(frameon=False)
    for _,g in balanced.groupby('event_id'):axs[1].plot(g.t,g.DE*100,color=GREY,alpha=.12,lw=.7)
    axs[1].plot(mean.index,mean.DE*100,'o-',color=BLUE,label='Mean of 77 fires');axs[1].axhline(0,color=GREY,lw=.6,ls=':')
    axs[1].set(xlabel='Post-fire year',ylabel='DE (points)',xticks=range(1,9));axs[1].legend(frameon=False)
    for ax in axs:ax.grid(alpha=.12)
    fig.tight_layout();save_image(fig,F/'mean_states.png',dpi=220,bbox_inches='tight');plt.close(fig)

    def draw(axs,g,number=None,recent=False):
        meta=g.iloc[0];eid=meta.event_id
        training=not recent and bool(roles.loc[eid,'used_for_fitting'])
        c=folds[int(meta.event_year)] if training else coef
        first=g[g.t.eq(1)].iloc[0];anchor=[[first.R_LG,first.R_ZP_TCC]]
        t=np.linspace(1,8,150);p,_=predict(anchor[0],t,coef=c);p=p[None,:,:2];base=quadratic(c,t)
        future=np.linspace(2,8,121);center,_=predict(anchor[0],future,coef=c);center=center[None,:,:2]
        for j,(ax,(k,col,label)) in enumerate(zip(axs,TARGETS)):
            y=p[0,:,j] if j<2 else p[0,:,1]-p[0,:,0]
            b=base[:,j] if j<2 else base[:,1]-base[:,0]
            cent=center[0,:,j] if j<2 else center[0,:,1]-center[0,:,0]
            for cov,alpha in [(.95,.07),(.9,.13),(.8,.26)]:
                w=widths[widths.target.eq(k)&widths.target_coverage.eq(cov)].sort_values('t')
                h=np.interp(future,w.t,w.half_width)
                ax.fill_between(future,(cent-h)*100,(cent+h)*100,color=BLUE,alpha=alpha,linewidth=0)
            ax.axvspan(.87,1.13,color='#EFF1F2',zorder=0)
            ax.plot(t,b*100,'--',color=GREY,lw=1.2,label='Quadratic')
            ax.plot(t,y*100,color=BLUE,lw=1.5,label='Amplitude cap')
            ax.plot(g.t,g[col]*100,'o-',color=BLACK,lw=1,ms=2.5,label='Observed')
            ax.set(xlim=(.85,8.15),xticks=[1,2,4,6,8],xlabel='Post-fire year',ylabel=label+' (points)')
            ax.grid(alpha=.12);ax.tick_params(labelsize=8)
            if k=='DE':ax.axhline(0,color=GREY,lw=.6,ls=':')
        title=('' if number is None else f'{number:02d}  ')+str(meta.event_name)+' '+str(int(meta.event_year))
        if recent:status='Recent fire application'
        else:
            title+='  '+{'DE下降':'DE decreases','基本不变':'DE approximately unchanged','DE上升':'DE increases','观测未满8年':'Fewer than 8 observed years'}[roles.loc[eid,'trajectory_group']]
            if training:status='Training fire; CV by ignition year'
            elif roles.loc[eid,'included_in_test_score']:status='Retrospective test fire'
            else:status='Supplementary fire'
        axs[0].set_title(title+'\n'+status,loc='left',fontsize=7.4,pad=9)
        for ax in axs[1:]:ax.set_title(' ',pad=9)
        axs[0].legend(frameon=False,fontsize=6,loc='best')
        pp,_=predict(anchor[0],g.t.to_numpy(),coef=c);pp=pp[None,:,:2];bb=quadratic(c,g.t.to_numpy())
        for j,(_,v) in enumerate(g.iterrows()):
            for k,(target,col,_) in enumerate(TARGETS):
                plotted.append(dict(event_id=eid,t=int(v.t),target=target,observed=float(v[col]),
                    prediction=float(pp[0,j,k] if k<2 else pp[0,j,1]-pp[0,j,0]),
                    quadratic=float(bb[j,k] if k<2 else bb[j,1]-bb[j,0]),recent=recent))
    inventory=roles.reset_index();inventory['order']=inventory.trajectory_group.map({'DE下降':0,'基本不变':1,'DE上升':2,'观测未满8年':3})
    inventory=inventory.sort_values(['order','event_year','event_name','event_id']).reset_index(drop=True)
    inventory['case_number']=np.arange(1,len(inventory)+1)
    inventory.to_csv(Q/'curve_inventory_en.csv',index=False)
    with PdfPages(OUT/'forest_v5_all_case_curves_EN.pdf') as pdf:
        for start in range(0,len(inventory),3):
            fig,axs=plt.subplots(3,3,figsize=(10.3,11.1));sub=inventory.iloc[start:start+3]
            for j,(_,case) in enumerate(sub.iterrows()):draw(axs[j],d[d.event_id.eq(case.event_id)].sort_values('t'),int(case.case_number))
            for j in range(len(sub),3):
                for ax in axs[j]:ax.axis('off')
            fig.subplots_adjust(hspace=.66,wspace=.34,top=.92,bottom=.105,left=.08,right=.98)
            fig.legend(handles=[Patch(facecolor=BLUE,alpha=a,label=f'{p}% target interval') for p,a in [(80,.40),(90,.20),(95,.07)]],loc='upper center',ncol=3,frameon=False,fontsize=8)
            fig.text(.08,.060,f'Cases {start+1}–{min(start+3,len(inventory))} of 81. LG and canopy cover are predicted separately; DE is their difference.',fontsize=7.4,color='#515B62')
            fig.text(.08,.040,'Grey: quadratic. Blue: amplitude cap. Black: observed. Training and retrospective tests are reported separately.',fontsize=7.5,color='#515B62')
            fig.text(.08,.021,'Half-widths use held-out training errors and are fixed by indicator and year. Year 1 is not scored; future observations are not imputed.',fontsize=7.5,color='#515B62')
            pdf.savefig(fig);plt.close(fig)
    recent=pd.read_csv(R/'data/recent_states.csv')
    recent=pd.concat([recent[recent.event_name.eq('PARK')],d[d.event_name.isin(['DIXIE','CALDOR','CREEK'])]],ignore_index=True)
    for i,names in enumerate([['PARK','DIXIE'],['CALDOR','CREEK']],1):
        fig,axs=plt.subplots(2,3,figsize=(9.4,6.6))
        for axes,name in zip(axs,names):draw(axes,recent[recent.event_name.eq(name)].sort_values('t'),recent=True)
        fig.subplots_adjust(hspace=.66,wspace=.35,top=.9,bottom=.1,left=.08,right=.99)
        save_image(fig,F/f'recent_{i}.png',dpi=220,bbox_inches='tight');plt.close(fig)
    pd.DataFrame(plotted).drop_duplicates(['event_id','t','target']).to_csv(Q/'plot_values_en.csv',index=False)
    print('Rendered81 fire cases in27 atlas pages.')

if __name__=='__main__':main()
