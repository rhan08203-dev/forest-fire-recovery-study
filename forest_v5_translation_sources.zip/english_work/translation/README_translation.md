# English translation materials

English translation and English figure labels prepared by ChatGPT at the author's request on 26 October 2026. This package changes presentation and language only; it does not refit the scientific models, alter the data, or replace the original research archive.

## Deliverables

- forest_v5_full_report_EN.pdf and .docx: complete English translation, 26 pages.
- forest_v5_full_report_ZH_EN.pdf: 26 paired pages, Chinese on the left and English on the right.
- forest_v5_all_case_curves_EN.pdf: all 81 fires with English figure labels, 27 pages.

The standalone documents are published alongside this translation-source package in the GitHub repository. The original Chinese report is the translation source. Tables and equations retain the original values. English figure records are identical to the original plotted records.

## Translation source and checks

english_work/translation/paragraphs_en.json contains the complete paragraph translations. build_english_report.py contains the table translations and document assembly. translation_alignment.json records paragraph and table pairs. make_english_figures.py uses the original model and saved results to relabel the plots. make_parallel_pdf.py places the two report pages side by side. verify_translation.py checks all numerical table tokens, 1,914 plotted observation/prediction records, source equation images, page counts and PDF text bounds. translation_verification.json records the completed checks.

## Rebuild

Use Python 3.12 with python-docx, Pillow, NumPy, pandas, matplotlib and PyMuPDF. LibreOffice or an equivalent DOCX-to-PDF renderer is required for PDF conversion. The original research dependencies remain in the original archive.

1. Extract this source package into an empty working directory. Extract the existing forest_v5_reproducible_research.zip into english_work/ so that english_work/analysis/forest_recovery/ and english_work/output/forest_recovery_report/ exist. The archive itself must remain unchanged.
2. Copy the existing Chinese forest_v5_full_report.docx to english_source/forest_v5_full_report(1).docx. Its expected SHA-256 is a8f552dd1fa927c77904cecfa40844dc4632a7897cdf86ac7971e0300a94a8f9. The Chinese PDF expected by the parallel builder is english_work/output/forest_recovery_report/forest_v5_full_report.pdf.
3. Run python english_work/translation/make_english_figures.py, then python english_work/translation/build_english_report.py.
4. Convert output/forest_report_english/forest_v5_full_report_EN.docx to output/forest_report_english/qa_en_final/forest_v5_full_report_EN.pdf. The delivered edition uses Arial-compatible font rendering, 10.5-point body text and 1.15 line spacing. Font availability can change pagination; inspect the 26-page layout before pairing it with the Chinese pages.
5. Run python english_work/translation/make_parallel_pdf.py and python english_work/translation/verify_translation.py.

No GEE sign-in is needed for translation or relabelling from the saved inputs. The source scripts retain the model's original event-role keys. This translation check verifies preservation of the supplied numerical content; it does not independently establish ecological validity of the original observations.
