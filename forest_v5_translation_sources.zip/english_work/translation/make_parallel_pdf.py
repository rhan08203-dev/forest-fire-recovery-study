"""Place the unmodified Chinese PDF beside its matching English page."""
from pathlib import Path
import fitz,shutil
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'output/forest_report_english'

def main():
    shutil.copyfile(OUT/'qa_en_final/forest_v5_full_report_EN.pdf',OUT/'forest_v5_full_report_EN.pdf')
    zh=fitz.open(ROOT/'english_work/output/forest_recovery_report/forest_v5_full_report.pdf')
    en=fitz.open(OUT/'forest_v5_full_report_EN.pdf')
    assert len(zh)==len(en)==26
    result=fitz.open();W,H=fitz.paper_size('a3-l')
    for i in range(26):
        page=result.new_page(width=W,height=H)
        for doc,left,label in [(zh,0,'Chinese original'),(en,W/2,'English translation')]:
            outer=fitz.Rect(left+4,22,left+W/2-4,H-4)
            page.show_pdf_page(outer,doc,i,keep_proportion=True)
            page.insert_text((left+14,14),f'{label}  |  page {i+1}',fontsize=8,fontname='helv',color=(.25,.25,.25))
            source=doc[i].rect;scale=min(outer.width/source.width,outer.height/source.height)
            x=outer.x0+(outer.width-source.width*scale)/2
            y=outer.y0+(outer.height-source.height*scale)/2
            for link in doc[i].get_links():
                if link.get('kind')==fitz.LINK_URI:
                    r=link['from'];rect=fitz.Rect(x+r.x0*scale,y+r.y0*scale,x+r.x1*scale,y+r.y1*scale)
                    page.insert_link({'kind':fitz.LINK_URI,'from':rect,'uri':link['uri']})
        page.draw_line((W/2,20),(W/2,H-5),color=(.82,.82,.82),width=.4)
    result.set_metadata({'title':'Forest Fire Recovery Study Chinese English Parallel Report',
        'subject':'Matching Chinese original and English translation pages',
        'creator':'Research translation materials'})
    result.save(OUT/'forest_v5_full_report_ZH_EN.pdf',garbage=4,deflate=True)
    print('26 paired Chinese–English pages saved.')

if __name__=='__main__':main()
