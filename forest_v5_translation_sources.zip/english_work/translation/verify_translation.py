"""Check that the English presentation preserves the source numerical content."""
from pathlib import Path
import hashlib, json, re, zipfile
import fitz
import pandas as pd
from docx import Document

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OUT = ROOT / 'output/forest_report_english'
SOURCE = ROOT / 'english_source/forest_v5_full_report(1).docx'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    alignment = json.loads((HERE/'translation_alignment.json').read_text())
    a, b = Document(SOURCE), Document(OUT/'forest_v5_full_report_EN.docx')
    assert len(a.paragraphs) == len(b.paragraphs) == 202
    assert len(a.tables) == len(b.tables) == 16
    for pair in alignment['paragraph_pairs']:
        assert not pair['zh'].strip() or pair['en'].strip()
    # The report builder asserts exact numerical-token equality in every table cell.
    assert alignment['numeric_table_cells_checked'] == 355
    with zipfile.ZipFile(SOURCE) as za, zipfile.ZipFile(OUT/'forest_v5_full_report_EN.docx') as zb:
        media = [p for p in za.namelist() if p.startswith('word/media/')]
        same = [p for p in media if za.read(p) == zb.read(p)]
        changed = [p for p in media if za.read(p) != zb.read(p)]
        assert len(changed) == 3, changed  # Only English-labelled plots change.
    old = pd.read_csv(ROOT/'english_work/analysis/forest_recovery/results/plot_values.csv')
    new = pd.read_csv(HERE/'results/plot_values_en.csv')
    keys = ['event_id','t','target']
    merged = old.merge(new,on=keys,suffixes=('_zh','_en'),validate='one_to_one')
    assert len(merged) == len(old) == len(new) == 1914
    differences = {}
    for column in ['observed','prediction','quadratic']:
        x,y = merged[column+'_zh'], merged[column+'_en']
        assert x.isna().equals(y.isna())
        differences[column] = float((x-y).abs().max())
        assert differences[column] == 0
    counts, cjk, outside = {}, {}, []
    for name in ['forest_v5_full_report_EN.pdf','forest_v5_full_report_ZH_EN.pdf','forest_v5_all_case_curves_EN.pdf']:
        doc = fitz.open(OUT/name)
        counts[name] = len(doc)
        if 'ZH_EN' not in name:
            cjk[name] = len(re.findall(r'[\u3400-\u9fff]', ''.join(p.get_text() for p in doc)))
            assert cjk[name] == 0
        for i,page in enumerate(doc):
            bounds = page.rect + (-1,-1,1,1)
            for block in page.get_text('blocks'):
                if block[6] == 0 and not bounds.contains(fitz.Rect(block[:4])):
                    outside.append([name,i+1,block[:4]])
    assert counts == {'forest_v5_full_report_EN.pdf':26,'forest_v5_full_report_ZH_EN.pdf':26,'forest_v5_all_case_curves_EN.pdf':27}
    assert not outside, outside
    result = {
        'source_DOCX_SHA256':sha(SOURCE),
        'paragraphs':202,'tables':16,'numeric_table_cells_preserved':355,
        'unchanged_source_media_files':len(same),'changed_media_files_English_plots_only':changed,
        'plot_records_checked':len(merged),'maximum_numerical_plot_difference':differences,
        'PDF_pages':counts,'CJK_characters_in_English_PDF_text':cjk,
        'text_blocks_outside_pages':outside,
        'visual_review':'All 26 English report pages; all atlas and parallel pages in contact sheets, with selected full-size plot and parallel pages.'
    }
    (HERE/'translation_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__ == '__main__':
    main()
