"""Translate the report without changing its numerical tables or equations."""
from pathlib import Path
from copy import deepcopy
from io import BytesIO
import hashlib,json,re
from docx import Document
from docx.shared import Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from PIL import Image

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'english_source/forest_v5_full_report(1).docx'
OUT=ROOT/'output/forest_report_english'
T={
 '样本用途':'Sample use','火灾数':'Fires','观测与评价':'Observations and evaluation',
 '函数拟合及交叉验证':'Fitting and cross-validation','完整八年记录':'Complete eight-year records',
 '回顾性检验':'Retrospective test','第2—8年评价':'Years 2–8 evaluated',
 '补充观测':'Supplementary observations','按已有年份核对':'Available years checked',
 '对象':'Indicator','条件成立时的校正量':'Correction when the condition is met','其他情况':'Otherwise',
 'R_ZP(1)＜0.46或＞0.64：\ns_ZP＝e_ZP':'R_ZP(1) < 0.46 or > 0.64:\ns_ZP = e_ZP',
 's_ZP＝0.25e_ZP':'s_ZP = 0.25e_ZP',
 'ZP区间外，且|e_LG|≥0.12：\ns_LG＝sign(e_LG)×min(|e_LG|,|s_ZP|)':'ZP outside the interval and |e_LG| ≥ 0.12:\ns_LG = sign(e_LG) × min(|e_LG|, |s_ZP|)',
 's_LG＝e_LG×0.5^(t−1)':'s_LG = e_LG × 0.5^(t−1)',
 '火后年份':'Post-fire year','平均LG':'Mean LG','平均树冠覆盖':'Mean canopy cover','平均DE':'Mean DE',
 '方案':'Method','树冠覆盖RMSE':'Canopy-cover RMSE','二次函数':'Quadratic function','幅度上限校正':'Amplitude cap correction',
 '目标':'Target','树冠覆盖':'Canopy cover','偏差':'Bias','二次RMSE':'Quadratic RMSE','上限校正RMSE':'Corrected RMSE',
 '观测标准差':'Observed SD','上限校正R²':'Corrected R²',
 '火灾及首年':'Fire and first observed year','LG首年':'First-year LG','ZP首年':'First-year ZP_TCC','校正分支':'Correction applied',
 'LG衰减、ZP四分之一':'LG decay; one-quarter ZP shift','LG幅度上限、ZP完整':'LG cap; full ZP shift',
 '火灾 第八年日历年':'Fire and eighth-year calendar date','LG预测':'LG prediction','ZP预测':'ZP prediction','DE预测':'DE prediction',
 '训练火灾':'Training fire','年份':'Year','检验火灾':'Test fire',
 '80%目标':'80% target','90%目标':'90% target','95%目标':'95% target'
}

def set_text(p,s):
    props=deepcopy(p.runs[0]._r.rPr) if p.runs and p.runs[0]._r.rPr is not None else None
    for e in list(p._p):
        if not e.tag.endswith('}pPr'):p._p.remove(e)
    run=p.add_run(s)
    if props is not None:run._r.insert(0,props)

def source_link(p,target):
    h=OxmlElement('w:hyperlink');h.set(qn('r:id'),p.part.relate_to(target,'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink',is_external=True))
    run=OxmlElement('w:r');pr=OxmlElement('w:rPr');color=OxmlElement('w:color');color.set(qn('w:val'),'356475');pr.append(color);run.append(pr)
    txt=OxmlElement('w:t');txt.set(qn('xml:space'),'preserve');txt.text=' Source';run.append(txt);h.append(run);p._p.append(h)

def numbers(s):return re.findall(r'[−-]?\d+(?:\.\d+)?%?',s.replace('／','/'))

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    en=json.loads((HERE/'paragraphs_en.json').read_text());d=Document(SOURCE);original=Document(SOURCE)
    assert len(d.paragraphs)==202 and len(d.tables)==16
    nonempty={str(i) for i,p in enumerate(d.paragraphs) if p.text.strip()}
    assert set(en)==nonempty,(nonempty-set(en),set(en)-nonempty)
    links={}
    for i,p in enumerate(d.paragraphs):
        for h in p._p.xpath('.//w:hyperlink'):
            rid=h.get(qn('r:id'))
            if rid:links.setdefault(i,[]).append(d.part.rels[rid].target_ref)
        if str(i) in en:set_text(p,en[str(i)])
        if i in links:
            for link in links[i]:source_link(p,link)
    translated_cells=0;numeric_cells=0
    for src_table,table in zip(original.tables,d.tables):
        for src_row,row in zip(src_table.rows,table.rows):
            for old,c in zip(src_row.cells,row.cells):
                value=T.get(old.text,old.text)
                if re.search('[\u3400-\u9fff]',value):raise ValueError('Untranslated table cell: '+value)
                for p in list(c.paragraphs)[1:]:p._p.getparent().remove(p._p)
                set_text(c.paragraphs[0],value)
                assert numbers(old.text)==numbers(value),(old.text,value)
                numeric_cells+=bool(numbers(value));translated_cells+=old.text!=value
    for style in d.styles:
        if hasattr(style,'font'):
            style.font.name='Arial';style.font.color.rgb=RGBColor(0,0,0)
    for p in d.paragraphs:
        for run in p.runs:
            run.font.name='Arial'
            if p.style.name.startswith(('Heading','Title','Subtitle')):run.font.color.rgb=RGBColor(0,0,0)
    for table in d.tables:
        for row in table.rows:
            for c in row.cells:
                for p in c.paragraphs:
                    for run in p.runs:run.font.name='Arial'
    d.styles['Normal'].font.size=Pt(10.5)
    d.styles['Normal'].paragraph_format.line_spacing=1.15
    d.styles['Normal'].paragraph_format.space_after=Pt(5)
    # English legends are drawn from the same prediction values and intervals.
    for rid,name in [('rId13','mean_states.png'),('rId15','recent_1.png'),('rId16','recent_2.png')]:
        d.part.related_parts[rid]._blob=(HERE/'figures'/name).read_bytes()
    for part in d.part.related_parts.values():
        if part.content_type.startswith('image/'):
            with Image.open(BytesIO(part.blob)) as im:im.load()
    d.core_properties.title=en['0'];d.core_properties.subject='English translation of the Chinese forest-fire research report'
    d.core_properties.comments='English translation prepared by ChatGPT at the author’s request. Scientific values and source equations preserved.'
    target=OUT/'forest_v5_full_report_EN.docx';d.save(target)
    alignment={
        'source_DOCX_SHA256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        'paragraph_pairs':[dict(id=f'P{i:03d}',zh=p.text,en=en.get(str(i),'')) for i,p in enumerate(original.paragraphs)],
        'table_pairs':[dict(id=f'T{i:02d}',zh=[[c.text for c in r.cells] for r in a.rows],en=[[c.text for c in r.cells] for r in b.rows]) for i,(a,b) in enumerate(zip(original.tables,d.tables))],
        'numeric_table_cells_checked':numeric_cells,'translated_table_cells':translated_cells,
        'all_nonempty_source_paragraphs_translated':True,'reference_links_preserved':len(links)}
    (HERE/'translation_alignment.json').write_text(json.dumps(alignment,ensure_ascii=False,indent=2))
    print(json.dumps({k:v for k,v in alignment.items() if k not in ['paragraph_pairs','table_pairs']},indent=2))

if __name__=='__main__':main()
